import Navbar from "../Navbar"
import "./index.css"

 const Home = () => {
  return (
    <>
    <Navbar />    
     <div className="home-container">
        <div className="content-container">
            <h1 className="heading">AS WE EVOLVE, OUR HOMES <br/> SHOULD TOO</h1>
        </div>
    </div>
    </>
   
  )

}


export default Home